<?php
/*
Plugin Name: Mpay支付解锁内容（支付宝+微信）后台设置版
Description: 使用Mpay聚合支付（支持支付宝+微信），支付成功后自动解锁隐藏内容，使用短代码 [mpay_unlock price="0.01" name="测试内容"]隐藏内容[/mpay_unlock]，备注说明一下，因为插件使用缓存记录支付行为并解锁，所以不要开启缓存功能！！！影响使用效果!!!!
Version: 1.3
Author: 码铃薯
*/

// --------------- 后台设置页面 -----------------
add_action('admin_menu', function() {
    add_options_page('Mpay支付设置', 'Mpay支付', 'manage_options', 'mpay-settings', 'mpay_settings_page');
});

function mpay_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die('权限不足');
    }

    if (isset($_POST['mpay_pid'], $_POST['mpay_key'], $_POST['mpay_gateway']) && check_admin_referer('mpay_save_settings')) {
        update_option('mpay_pid', sanitize_text_field($_POST['mpay_pid']));
        update_option('mpay_key', sanitize_text_field($_POST['mpay_key']));
        update_option('mpay_gateway', esc_url_raw($_POST['mpay_gateway']));
        echo '<div class="updated"><p>设置已保存</p></div>';
    }

    $pid = get_option('mpay_pid', '');
    $key = get_option('mpay_key', '');
	$raw_gateway = trim(get_option('mpay_gateway', ''));
    $gateway = $raw_gateway ? rtrim($raw_gateway, '/') . '/submit.php' : '';

    ?>
    <div class="wrap">
        <h1>Mpay支付设置</h1>
        <form method="post" action="">
            <?php wp_nonce_field('mpay_save_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="mpay_pid">PID</label></th>
                    <td><input name="mpay_pid" type="text" id="mpay_pid" value="<?php echo esc_attr($pid); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="mpay_key">KEY</label></th>
                    <td><input name="mpay_key" type="text" id="mpay_key" value="<?php echo esc_attr($key); ?>" class="regular-text"></td>
                </tr>
				<tr>
                    <th><label for="mpay_gateway">支付网关URL</label></th>
                    <td><input name="mpay_gateway" type="text" id="mpay_gateway" value="<?php echo esc_attr($gateway); ?>" class="regular-text">
                    <p class="description">输入你的支付平台网址(如果你自己搭建了mpay平台)，如果没有可以参考<code>https://mpay.52yzk.com</code></p>
                    </td>
                </tr>

            </table>
            <?php submit_button('保存设置'); ?>
        </form>
    </div>
    <?php
}
// --------------- 结束后台设置 -----------------

// 动态设置 meta description
add_action('wp_head', 'mpay_dynamic_meta_description');
function mpay_dynamic_meta_description() {
    if (is_singular()) {
        global $post;
        $post_id = $post->ID;

        $cookie_alipay = isset($_COOKIE['mpay_unlocked_alipay_' . $post_id]) && $_COOKIE['mpay_unlocked_alipay_' . $post_id] === '1';
        $cookie_wx = isset($_COOKIE['mpay_unlocked_wx_' . $post_id]) && $_COOKIE['mpay_unlocked_wx_' . $post_id] === '1';
        $unlocked = $cookie_alipay || $cookie_wx;

        if ($unlocked) {
            $description = get_the_excerpt($post_id);
        } else {
            $description = '支付解锁内容，点击支付查看。';
        }

        echo '<meta name="description" content="' . esc_attr($description) . '" />' . "\n";
    }
}

add_shortcode('mpay_unlock', function($atts, $content = null) {
    if (!is_singular()) return '';

    global $post;
    $post_id = isset($post->ID) ? intval($post->ID) : 0;
    if (!$post_id) return '';

    $atts = shortcode_atts([
        'price' => '1.00',
        'name' => get_the_title($post_id),
    ], $atts);

    // 从后台设置读取配置
    $pid = get_option('mpay_pid', '');
    $key = get_option('mpay_key', '');
	// 获取处理后的网关地址
    $raw_gateway = trim(get_option('mpay_gateway', ''));
    $gateway = $raw_gateway ? rtrim($raw_gateway, '/') . '/submit.php' : '';

    if (empty($pid) || empty($key)) {
        return '<p style="color:red;">请在插件设置页面配置PID和KEY！</p>';
    }

    $cookie_alipay = isset($_COOKIE['mpay_unlocked_alipay_' . $post_id]) && $_COOKIE['mpay_unlocked_alipay_' . $post_id] === '1';
    $cookie_wx = isset($_COOKIE['mpay_unlocked_wx_' . $post_id]) && $_COOKIE['mpay_unlocked_wx_' . $post_id] === '1';
    $unlocked = $cookie_alipay || $cookie_wx;

    $order_id = 'order_' . time() . rand(1000, 9999);
    $notify_url = site_url('/mpay-notify');
    $return_url = site_url('/mpay-return?post_id=' . $post_id);

    function generate_pay_url($type, $pid, $key, $order_id, $notify_url, $return_url, $name, $price, $gateway) {
        $data = [
            'pid' => $pid,
            'type' => $type,
            'out_trade_no' => $order_id . "_$type",
            'notify_url' => $notify_url,
            'return_url' => $return_url,
            'name' => $name,
            'money' => $price,
            'sign_type' => 'MD5'
        ];
        ksort($data);
        $sign_str = '';
        foreach ($data as $k => $v) {
            if ($k !== 'sign' && $k !== 'sign_type' && $v !== '') {
                $sign_str .= "$k=$v&";
            }
        }
        $sign_str = rtrim($sign_str, '&') . $key;
        $data['sign'] = md5($sign_str);

        return $gateway . '?' . http_build_query($data);
    }

    $alipay_url = generate_pay_url('alipay', $pid, $key, $order_id, $notify_url, $return_url, $atts['name'], $atts['price'], $gateway);
    $wxpay_url = generate_pay_url('wxpay', $pid, $key, $order_id, $notify_url, $return_url, $atts['name'], $atts['price'], $gateway);

    ob_start();
    ?>
    <div id="mpay-container-<?php echo $post_id; ?>">
        <?php if (!$unlocked): ?>
            <div style="border:1px solid #ccc;padding:15px;background:#fff9f9;">
                <p><strong>此内容需支付 <?php echo esc_html($atts['price']); ?> 元查看</strong></p>
                <a href="<?php echo esc_url($alipay_url); ?>" target="_blank"><img src="/wp-content/plugins/mpay-content-unlocker/img/alipay.jpg" width="160" alt="支付宝支付"></a>
                <a href="<?php echo esc_url($wxpay_url); ?>" target="_blank"><img src="/wp-content/plugins/mpay-content-unlocker/img/wxpay.jpg" width="160" alt="微信支付"></a>
                <p style="font-size:13px;color:#888;margin-top:10px;">支付完成后页面将自动刷新并解锁内容</p>
                <p style="font-size:13px;margin-top:10px;">如未解锁，请尝试<span style="color: #ff00ff;">刷新页面</span>或<span style="color: #0000ff;">登录后刷新</span></p>
            </div>
        <?php endif; ?>
        <div id="mpay-unlock-content-<?php echo $post_id; ?>"></div>
    </div>

    <script>
    (function(){
        const unlocked = <?php echo $unlocked ? 'true' : 'false'; ?>;
        if (unlocked) {
            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=mpay_get_content&post_id=<?php echo $post_id; ?>'
            }).then(response => response.text()).then(html => {
                document.getElementById('mpay-unlock-content-<?php echo $post_id; ?>').innerHTML = html;
            });
        }
    })();
    </script>
    <?php
    return ob_get_clean();
});

// 支付完成回调（用户跳转回来时）
add_action('init', function () {
    if (strpos($_SERVER['REQUEST_URI'], '/mpay-return') !== false && isset($_GET['post_id']) && isset($_GET['out_trade_no'])) {
        $post_id = intval($_GET['post_id']);
        $out_trade_no = $_GET['out_trade_no'];

        if (strpos($out_trade_no, 'alipay') !== false) {
            setcookie('mpay_unlocked_alipay_' . $post_id, '1', time() + 86400, '/');
            $_COOKIE['mpay_unlocked_alipay_' . $post_id] = '1';
        } elseif (strpos($out_trade_no, 'wxpay') !== false) {
            setcookie('mpay_unlocked_wx_' . $post_id, '1', time() + 86400, '/');
            $_COOKIE['mpay_unlocked_wx_' . $post_id] = '1';
        }

        echo '<p style="font-family:sans-serif;padding:2em;">✅ 支付成功，正在返回原页面...</p>';
        echo '<script>
            localStorage.setItem("mpay_unlocked_' . $post_id . '", "1");
            if (window.opener) {
                window.opener.postMessage({ unlock_post_id: ' . $post_id . ' }, "*");
            }
            setTimeout(function() {
                window.location.href = "' . get_permalink($post_id) . '";
            }, 1000);
        </script>';
        exit;
    }
});

// 通知接口处理
function mpay_notify_handler_combined() {
    $key = get_option('mpay_key', '');
    $data = $_GET;
    $sign = $data['sign'] ?? '';
    unset($data['sign'], $data['sign_type']);
    ksort($data);
    $sign_str = http_build_query($data) . $key;
    $verify_sign = md5($sign_str);

    if ($verify_sign === $sign && ($data['trade_status'] ?? '') === 'TRADE_SUCCESS') {
        echo 'success';
    } else {
        echo 'fail';
    }
    exit;
}
add_action('init', function () {
    if (strpos($_SERVER['REQUEST_URI'], '/mpay-notify') !== false) {
        mpay_notify_handler_combined();
    }
});

// 经典编辑器按钮支持
add_action('media_buttons', 'mpay_add_shortcode_button', 15);
function mpay_add_shortcode_button() {
    echo '<a href="#" id="insert-mpay-shortcode" class="button">插入支付解锁短代码</a>
    <script>
        jQuery(document).ready(function($){
            $("#insert-mpay-shortcode").click(function(e){
                e.preventDefault();
                send_to_editor(\'[mpay_unlock price="0.01" name="测试内容"]这里是隐藏的内容[/mpay_unlock]\');
            });
        });
    </script>';
}

// 禁止摘要执行短代码，防止首页/分类页显示支付UI
add_action('init', function() {
    remove_filter('the_excerpt', 'do_shortcode');
});

add_action('wp_ajax_mpay_get_content', 'mpay_ajax_get_content');
add_action('wp_ajax_nopriv_mpay_get_content', 'mpay_ajax_get_content');

function mpay_ajax_get_content() {
    $post_id = intval($_POST['post_id']);

    if (!$post_id || !get_post($post_id)) {
        wp_send_json_error('非法请求');
    }

    $alipay_cookie = isset($_COOKIE['mpay_unlocked_alipay_' . $post_id]) && $_COOKIE['mpay_unlocked_alipay_' . $post_id] === '1';
    $wx_cookie = isset($_COOKIE['mpay_unlocked_wx_' . $post_id]) && $_COOKIE['mpay_unlocked_wx_' . $post_id] === '1';

    $user_key = md5($_SERVER['REMOTE_ADDR'] . $_SERVER['HTTP_USER_AGENT']);
    $transient_check = get_transient("mpay_paid_{$post_id}_{$user_key}");

    if (!$alipay_cookie && !$wx_cookie && !$transient_check) {
        wp_send_json_error('未授权访问');
    }

    $post = get_post($post_id);
    if (!$post) {
        wp_send_json_error('文章不存在');
    }

    $pattern = get_shortcode_regex(['mpay_unlock']);
    if (preg_match_all('/' . $pattern . '/s', $post->post_content, $matches) && isset($matches[2], $matches[5])) {
        foreach ($matches[2] as $i => $shortcode_name) {
            if ($shortcode_name === 'mpay_unlock') {
                echo do_shortcode($matches[5][$i]);
            }
        }
    }

    wp_die();
}

